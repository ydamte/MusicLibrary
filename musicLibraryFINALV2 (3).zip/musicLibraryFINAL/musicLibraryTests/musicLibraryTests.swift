//
//  musicLibraryTests.swift
//  musicLibraryTests
//
//  Created by Yeabsera Damte on 11/16/24.
//

import Testing
@testable import musicLibrary

struct musicLibraryTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
